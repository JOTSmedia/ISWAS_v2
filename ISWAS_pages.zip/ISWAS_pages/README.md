# It Started With a Scream

Upload the *contents* of this folder to the repository root. Do not upload the zip itself and do not nest this folder inside another folder.

GitHub Pages: Settings, Pages, Deploy from a branch, branch main, folder / (root).

.nojekyll is included so every file is served.
