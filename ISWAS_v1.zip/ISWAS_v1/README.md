# It Started With a Scream

This folder is ready for GitHub Pages.

1. Create or open the repository (the repo name can be anything).
2. Upload these files to the repository root. Keep the folders as they are.
3. Settings, Pages, Build and deployment: Deploy from a branch. Branch: main. Folder: / (root).
4. The site will be at https://USER.github.io/REPO/

`.nojekyll` is included so GitHub serves every file.
